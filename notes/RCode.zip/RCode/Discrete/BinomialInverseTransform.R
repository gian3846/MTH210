n <- 10
p <- 0.4
q <- 1-p

prob <- numeric(length = n+1)
for(i in 1:(n+1))
{
  x <- i-1
  prob[i] <- choose(n, x) * (p^x) * (q^(n-x))
}

draws <- numeric(length = 1e3)
for(i in 1:1e3)
{
  uniform <- runif(1)
  sum <- prob[1]
  for(j in 1:n+1)
  {
    if(uniform <= sum)
    {
      draws[i] <- j-1
      break
    }
    else
    {
      sum = sum + prob[j+1]
    }
  }
}
hist(draws)

