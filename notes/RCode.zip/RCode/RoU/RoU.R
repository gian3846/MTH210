# e <- function()
# {
#   a <- 1
#   b <- 0
#   c <- 2/exp(1)
# 
#   accept <- FALSE
#   count <- 0
#   while(!accept)
#   {
#     count <- count + 1
#     u <- runif(1, 0, a)
#     v <- runif(1, b, c)
#     ratio <- sqrt(exp(-v/u))
#     if(u <= ratio)
#     {
#       accept <- TRUE
#     }
#   }
#   return(c(v/u, count))
# }

normal <- function(mu, sigmaSq)
{
  a <- (2*pi*sigmaSq)^(-1/4)
  xb <- (mu - sqrt((mu^2)+sigmaSq))/2
  xc <- (mu + sqrt((mu^2)+sigmaSq))/2
  b <- xb*sqrt(dnorm(xb, mu, sqrt(sigmaSq)))
  c <- xc*sqrt(dnorm(xc, mu, sqrt(sigmaSq)))

  accept <- FALSE
  count <- 0
  while(!accept)
  {
    count <- count + 1
    u <- runif(1, 0, a)
    v <- runif(1, b, c)
    ratio <- sqrt(dnorm(v/u, mu, sqrt(sigmaSq)))
    if(u <= ratio)
    {
      accept <- TRUE
    }
  }
  return(c(v/u, count, 2*a*(c-b)))
}

# N <- 1e3
# samp <- numeric(length = N)
# count <- numeric(length = N)
# for(i in 1:N)
# {
#   foo <- e()
#   samp[i] <- foo[1]
#   count[i] <- foo[2]
# }
# 
# hist(samp, breaks = 100, freq = F)
# plot(density(samp), xlim = c(0, 10))
# 2*(2/exp(1))
# mean(count)

N <- 1e3
samp <- numeric(length = N)
count <- numeric(length = N)
for(i in 1:N)
{
  foo <- normal(3, 1)
  samp[i] <- foo[1]
  count[i] <- foo[2]
}

hist(samp, breaks = 10, freq = F)
plot(density(samp))
foo[3]
mean(count)