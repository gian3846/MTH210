#################################################

cauchy <- function()
{
  u <- runif(1)
  return(tan(pi*(u - 0.5)))
}

x <- numeric(length = 1e4)

for(i in 1:1e4)
{
  x[i] <- cauchy()
}

hist(x)

#################################################