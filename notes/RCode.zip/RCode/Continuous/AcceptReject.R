#################################################

beta_4_3 <- function()
{
  accept = FALSE
  try = 0
  x = 0
  while(accept == FALSE)
  {
    u <- runif(1)
    g <- runif(1)
    
    ratio <- dbeta(g, 4, 3)/(2.08*dunif(g))
    try <- try+1
    
    if(u <= ratio)
    {
      x <- g
      accept <- TRUE
    }
  }
  draw <- numeric(length = 2)
  draw[1] <- x
  draw[2] <- try
  return(draw)
}

x <- numeric(length = 1e3)
tries <- numeric(length = 1e3)

for(i in 1:1e3)
{
  draw <- beta_4_3()
  x[i] <- draw[1]
  tries[i] <- draw[2]
}

mean(tries)

par(mfrow = c(1,2))

hist(x)
hist(tries)

#################################################

normal <- function()
{
  accept <- 0
  try <- 0
  x <- 0
  
  while(accept == 0)
  {
    u <- runif(1)
    g <- rcauchy(1)
    c <- 1.8
    ratio <- (dnorm(g)/(c*dcauchy(g)))
    
    try = try + 1
    if(u <= ratio)
    {
      x <- g
      accept <- 1
    }
  }
  draw <- c(x, try)
  return (draw)
}

x <- numeric(length = 1e3)
tries <- numeric(length = 1e3)

for(i in 1:1e3)
{
  draw <- normal()
  x[i] <- draw[1]
  tries[i] <- draw[2]
}

mean(tries)

par(mfrow = c(1,2))

hist(x)
hist(tries)

#################################################