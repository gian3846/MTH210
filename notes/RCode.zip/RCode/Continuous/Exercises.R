#################################################

exponential <- function(lambda = 1)
{
  u <- runif(1)
  x <- -(log(1-u)/lambda)
  return(x)
}

x <- numeric(length = 1e3)

for(i in 1:1e3)
{
  x[i] <- exponential(5)
}
mean(x)
hist(x)

#################################################

weibull <- function(lambda)
{
  u <- runif(1)
  x <- (-log(1-u))^(1/lambda)
  return (x)
}

x <- numeric(length = 1e3)

for(i in 1:1e3)
{
  x[i] <- weibull(.5)
}

hist(x)

#################################################