boxMuller <- function()
{
  u1 <- runif(1)
  u2 <- runif(1)
  
  theta <- 2*pi*u1
  d <- -2*log(u2)
  
  x <- sqrt(d) * cos(theta)
  y <- sqrt(d) * sin(theta)
  
  return (c(x, y))
}

N <- 1e3
samp <- numeric(length = N)

for(i in 1:(N/2))
{
  foo <- boxMuller();
  samp[2*i] <- foo[1]
  samp[(2*i)-1] <- foo[2]
}

hist(samp)