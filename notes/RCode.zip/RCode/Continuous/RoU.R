# Cauchy
drawCauchy <- function(a, b, c)
{
  accept <- FALSE
  count <- 0
  while(!accept)
  {
    count <- count + 1
    u <- runif(1, 0, a)
    v <- runif(1, b, c)
    if(u <= sqrt((1/pi)*(1/(1+(v/u)^2))))
    {
      prop <- v/u
      accept <- TRUE
    }
  }
  return (c(prop, count))
}

a <- 1/sqrt(pi)
b <- -1/sqrt(2*pi)
c <- 1/sqrt(2*pi)

N <- 1e3
samp <- numeric(length = N)
count <- numeric(length = N)

x <- seq(-100, 100, by = 0.1)
plot(x, dcauchy(x))
for(i in 1:N)
{
  foo <- drawCauchy(a, b, c)
  samp[i] <- foo[1]
  count[i] <- foo[2]
 points(samp[i], dcauchy(samp[i]), col = "red")
}
# hist(samp, breaks = 20)

# Comparing average number of draws needed
mean(count)

2*a*(c-b)