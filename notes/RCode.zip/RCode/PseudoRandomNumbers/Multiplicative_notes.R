m <- 2^31 - 1
a <- 7^5

seed = 2

x <- numeric(length = 1000)
x[1] <- seed

for(i in 2:1e3)
{
  x[i] <- (a*x[i-1]) %% m
}

x = x/m

hist(x)
