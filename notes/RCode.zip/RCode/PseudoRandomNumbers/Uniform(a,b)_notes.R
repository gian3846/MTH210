set.seed(1)

repeats <- 1e4
x <- runif(repeats)
a <- 5
b <- 10
U <- (b - a)*x + a

par(mfrow = c(1,2))
hist(U)
plot(1:repeats, U, type = "l")
