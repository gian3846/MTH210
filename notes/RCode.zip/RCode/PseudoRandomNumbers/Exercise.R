seed <- 5
m <- 1e4
a <- 2
n <- 1e4
numbers <- numeric(length = n)

numbers[1] <- a*seed
for(i in 2:n)
{
  numbers[i] <- (numbers[i-1]*a) %% m
}
numbers <- numbers/m

par(mfrow = c(2,1))
hist(numbers)
plot(1:n, numbers, type = "l")
