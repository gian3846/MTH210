seed <- 215
a <- 7^5
m <- (2^31)-1
c <- 3
x <- numeric(length = 1e3)

x[1] = (a*seed + c) %% m
for(i in 2:1000)
{
  x[i] = (a*x[i-1] + c) %% m
}

x <- x/m

hist(x)
plot(c(1:1e3), x, type = "l")

#################################################

seed <- 215
a <- 1
m <- 1e3
c <- 1
x <- numeric(length = 1e3)

x[1] = (a*seed + c) %% m
for(i in 2:1000)
{
  x[i] = (a*x[i-1] + c) %% m
}

x <- x/m

hist(x)
plot(c(1:1e3), x, type = "l")

#################################################
calcSum <- function(lambda)
{
  I <- floor(lambda)
  sum <- 0
  for(i in 0:(I-1))
  {
    temp = exp(-lambda + i*log(lambda) - lfactorial(i))
    sum = sum + temp
  }
  return (sum)
}

drawPoisson <- function(lambda)
{
  sum <- calcSum(lambda)
  I <- floor(lambda)
  
  accept <- FALSE
  u <- runif(1)
  while(!accept)
  {
    temp = exp(-lambda + I*log(lambda) - lfactorial(I))
    if((u > sum) & (u <= sum + temp))
    {
      accept = TRUE
    }
    else if(u <= sum)
    {
      I = I - 1
      temp = exp(-lambda + I*log(lambda) - lfactorial(I))
      sum = sum - temp
    }
    else if(u > (sum + temp))
    {
      sum = sum + temp
      I = I + 1
    }
  }
  return (I)
}

N <- 1e3
samp <- numeric(length = N)

lambda <- 26

for(i in 1:N)
{
  samp[i] <- drawPoisson(lambda)
}
hist(samp, breaks = 20)

x <- c(0:50)
plot(x, dpois(x, 26), type = "l")
plot(density(samp), type = "l")
mean(rpois(1e3, 26))
mean(samp)

#################################################

binom <- function(n, p)
{
  accept <- FALSE
  count <- 0
  
  x <- c(0:n)
  all_c <- (n+1)*(choose(n, x)*(p^x)*((1-p)^(n-x)))
  c <- max(all_c) + 0.0001
  
  while(!accept)
  {
    count = count + 1
    u <- runif(1)
    v <- runif(1, 0, (n+1))
    v <- floor(v)
    
    temp <- (((n+1)*choose(n, v)*(p^v)*((1-p)^(n-v)))/c)
    if(u < temp)
    {
      accept = TRUE
      prop <- v
    }
  }
  return (c(prop, count, c))
}

N <- 1e3
n <- 100
p <- 0.5
samp <- numeric(length = N)
count <- numeric(length = N)
c <- 0
for(i in 1:N)
{
  foo <- binom(n, p)
  samp[i] <- foo[1]
  count[i] <- foo[2]
  c <- foo[3]
}

hist(samp)
mean(samp)
mean(count)
c

#################################################

zip <- function(delta, lambda)
{
  u <- runif(1)
  if(u < delta)
  {
    return(0)
  }
  else
  {
    return (rpois(1, lambda))
  }
}

N <- 1e3
samp <- numeric(length = N)
for(i in 1:N)
{
  samp[i] <- zip(0.3, 25)
}

hist(samp)
plot(density(samp))

#################################################