#####  Lab 3

### Ratio of Uniforms
set.seed(1)
RoU <- function()
{
  accept <- 0
  count <- 0
  while(accept == 0)
  {
    u <- runif(1)
    v <- runif(1,0,2*exp(-1))
    count <- count + 1
    if(u <= sqrt(exp(-v/(2*u))))
    {
      accept = 1
      return (v/u)
    }
  }

}
samp2 <- replicate(1e4, RoU())
if(samp2 == samp) return("yes")
