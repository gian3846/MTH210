h <- function(x, y)
{
  return(x*y)
}
f <- function(x, y)
{
  return(exp(sin(x*y)))
}

N <- 1e3
samp <- matrix(0, N, 2)
for(i in 1:N)
{
  samp[i, ] <- runif(2, 0, pi)
}
num <- h(samp[ ,1], samp[ ,2]) * f(samp[ ,1], samp[ ,2])
den <- f(samp[ ,1], samp[ ,2])

integral <- sum(num)/sum(den)