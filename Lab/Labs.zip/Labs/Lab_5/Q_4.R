set.seed(1)
n <- 50
nu <- 2
y <- rt(n, df = nu)

f <- function(x, y, nu)
{
  val <- exp(-(x^2)/2)
  temp <- (-(nu+1)/2)*(log(1 + ((y-x)^2)/nu))
  temp <- sum(temp)
  temp <- exp(temp)
  val <- val * temp
  return(val)
}

n <- 1e2
est <- numeric(length = n)
for(j in 1:n)
{
  N <- 1e3
  samp <- rnorm(N, 0, 1)
  num <- numeric(length = N)
  den <- numeric(length = N)
  for(i in 1:N)
  {
    num[i] <- samp[i]*f(samp[i], y, nu)/dnorm(samp[i], 0, 1)
    den[i] <- f(samp[i], y, nu)/dnorm(samp[i], 0, 1)
  }
  
  est[j] <- sum(num)/sum(den)
}

mean(est)
var(est)