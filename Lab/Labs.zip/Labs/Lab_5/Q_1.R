# Beta(4, 5) Simple Importance Sampling

N <- 1e3
h <- function(x)
{
  return (exp(-x))
}
f <- function(x)
{
  return (dbeta(x, 4, 5))
}
Z <- runif(N, 0, 1)
func <- h(Z)*f(Z)/1
mean(func)

var(func)
# Beta(4, 5) Weighted Importance Sampling
N <- 1e3
h <- function(x)
{
  return (exp(-x))
}
f <- function(x)
{
  return (dbeta(x, 4, 5))
}
Z <- runif(N, 0, 1)
num <- sum((h(Z)*f(Z)))
den <- sum(f(Z))
num/den

n <- 1e2
est <- numeric(length = n)
for(i in 1:n)
{
  Z <- runif(N, 0, 1)
  num <- sum((h(Z)*f(Z)))
  den <- sum(f(Z))
  
  est[i] <- num/den
}
var(est)*N