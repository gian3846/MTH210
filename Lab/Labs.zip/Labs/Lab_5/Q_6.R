L <- function(a, b = 2, samp)
{
  val <- dgamma(samp, shape = a, scale = b)
  val <- prod(val)
  return(val)
}
logL <- function(a, b = 2, samp)
{
  val <- dgamma(samp, shape = a, scale = b)
  val <- log(val)
  val <- sum(val)
  return(val)
}

N <- 1e2
X <- rgamma(N, shape = 10, scale = 2)
a <- seq(5, 15, 0.1)
likelihood <- numeric(length = length(a))
logLikelihood <- numeric(length = length(a))

for(i in 1:length(a))
{
  likelihood[i] <- L(a[i], samp = X)
  logLikelihood[i] <- logL(a[i], samp = X)
}

par(mfrow = c(1, 2))
plot(a, likelihood, type = "l")
plot(a, logLikelihood, type = "l")