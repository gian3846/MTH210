L <- function(theta, x1, x2)
{
  val <- dnorm(x1, theta, 1) * dnorm(x2, theta, 1)
  return (val)
}

x1 <- 2
x2 <- 3
theta <- seq(0, 5, 0.1)
like <- numeric(length = length(theta))

for(i in 1:length(theta))
{
  like[i] <- L(theta[i], x1, x2)
}

plot(theta, like, type = "l")