set.seed(1)

reps <- 1e2
n <- 100
B <- 1e3
a <- 0.05
ends <- c(a/2, 1-a/2)
alpha <- 10
beta <- 5

np <- numeric(length = reps)
p <- numeric(length = reps)

for(r in 1:reps)
{
  dat <- rgamma(n, shape = alpha, rate = beta)
  
  npBoot <- numeric(length = B)
  for(i in 1:B)
  {
    foo <- sample(1:n, n, replace = T)
    bootSampNp <- dat[foo]
    npBoot[i] <- sd(bootSampNp)/mean(bootSampNp)
  }
  npInt <- quantile(npBoot, ends)
  np[r] <- ((npInt[1] <= 1/sqrt(alpha)) && (npInt[2] >= 1/sqrt(alpha)))
  
  ## parametric
  pBoot <- numeric(length = B)
  XBar <- mean(dat)
  varHat <- var(dat)
  for(i in 1:B)
  {
    bootSamp <- rgamma(n, shape = sqrt((XBar^2)/varHat), rate = XBar/varHat)
    pBoot[i] <- sd(bootSamp)/mean(bootSamp)
  }
  pInt <- quantile(npBoot, ends)
  p[r] <- ((pInt[1] <= 1/sqrt(alpha)) && (pInt[2] >= 1/sqrt(alpha)))
  
  print((npInt == pInt))
}

mean(np)
mean(p)