set.seed(1) 
alpha <- 10 
beta <- 5
n <- 100
dat <- rgamma(n, shape = alpha, rate = beta)

B <- 1e3
a <- 0.05
ends <- c(a/2, 1-a/2)

est <- sd(dat)/mean(dat)

## non-parametric
npBoot <- numeric(length = B)
for(i in 1:B)
{
  foo <- sample(1:n, n, replace = T)
  bootSamp <- dat[foo]
  npBoot[i] <- sd(bootSamp)/mean(bootSamp)
}
npInt <- quantile(npBoot, ends)

## parametric
pBoot <- numeric(length = B)
XBar <- mean(dat)
varHat <- var(dat)
for(i in 1:B)
{
  bootSamp <- rgamma(n, shape = sqrt((XBar^2)/varHat), rate = XBar/varHat)
  pBoot[i] <- sd(bootSamp)/mean(bootSamp)
}
pInt <- quantile(npBoot, ends)