set.seed(1)

reps <- 1e2
n <- 1e2
B <- 1e3

theta <- 5
alpha <- 0.05
ends <- c(alpha/2, 1 - alpha/2)

np <- numeric(length = reps)
p <- numeric(length = reps)

for(r in 1:reps)
{
  X <- rnorm(n, theta, 1)
  
  npBoot <- numeric(length = B)
  for(i in 1:B)
  {
    foo <- sample(1:n, n, replace = T)
    bootSamp <- X[foo]
    npBoot[i] <- mean(bootSamp)
  }
  npInt <- quantile(npBoot, ends)
  
  np[r] <- ((npInt[1] <= theta) && (npInt[2] >= theta))
  
  pBoot <- numeric(length = B)
  XBar <- mean(X)
  for(i in 1:B)
  {
    bootSamp <- rnorm(n, XBar, 1)
    pBoot[i] <- mean(bootSamp)
  }
  pInt <- quantile(pBoot, ends)
  
  p[r] <- ((pInt[1] <= theta) && (pInt[2] >= theta))
}

mean(np)
mean(p)

# n = 10, np = 0.86, p = 0.89
# n = 100, np = 0.95, p = 0.95
# n = 1000, np = 0.97, p = 0.96