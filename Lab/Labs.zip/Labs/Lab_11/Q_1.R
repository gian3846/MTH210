set.seed(1)

n <- 1e3
theta <- 5
X <- rnorm(n, theta, 1)

B <- 1e3
## non-parametric bootstrap
npBoot <- numeric(length = B)
for(i in 1:B)
{
  foo <- sample(1:n, n, replace = T)
  bootSamp <- X[foo]
  npBoot[i] <- mean(bootSamp)
}

## parametric bootstrap
pBoot <- numeric(length = B)
XBar <- mean(X)
for(i in 1:B)
{
  bootSamp <- rnorm(n, XBar, 1)
  pBoot[i] <- mean(bootSamp)
}

## Plotting

x <- seq(theta - 6/sqrt(n), theta + 6/sqrt(n), length = 500)
plot(x, dnorm(x, mean = mean(X), sd = 1/sqrt(n)), type = "l", ylab = "density")
lines(density(npBoot), col = "red")
lines(density(pBoot), col = "blue")
legend("topleft", legend = c("Real", "Non - Paramteric", "Parametric"), col = c("black", "red", "blue"), lty = 1)
