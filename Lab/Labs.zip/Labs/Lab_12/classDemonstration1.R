#########################################
## Visualizging SGA objective functions
#########################################
# consider N(mu, 1) and the likelihood for mu
set.seed(1)
mu <- 5
n <- 1e3
dat <- rnorm(n, mean = mu, sd = 1)
hist(dat)

# plotting objective functions
logf <- function(x, mu)
{
  -sum((x-mu)^2/2)/length(x)
}

# finding gradient
f.gradient <- function(x, mu)
{
  -sum(x - mu)/length(x)
}

######### full loglikelihood #########
B <- 5e2
mu.ax <- seq(-5, 15, length = B)
log.like <- length(B)
for(i in 1:length(mu.ax))
{
  log.like[i]  <- logf(dat, mu.ax[i])
}
plot(mu.ax, log.like, type = 'l', lwd = 2.5)


######### SGA without batching #########
sga.like <- matrix(0, nrow = B, ncol = 1e2)
for(j in 1:1e2)
{
  chosen <- sample(1:n, 1) # stochastic part
  for(i in 1:length(mu.ax))
  {
    sga.like[i,j]  <- logf(dat[chosen], mu.ax[i])
  }
  lines(mu.ax, sga.like[,j], col =  adjustcolor("red", alpha.f = .4))
  points(y = 1, x = dat[chosen], pch = 16, col = "purple")
  #Sys.sleep(2)
}




######### Mini Batch #########
sga.like <- matrix(0, nrow = B, ncol = 1e2)
# likelihood for each randomly chosen datapoint
for(j in 1:1e2)
{
  chosen <- sample(1:n, 100) #mini batch of size 10
  for(i in 1:length(mu.ax))
  {
    sga.like[i,j]  <- logf(dat[chosen], mu.ax[i])
  }
  lines(mu.ax, sga.like[,j], col =  adjustcolor("blue", alpha.f = .4))
  points(y = 1, x = mean(dat[chosen]), pch = 16, col = "orange")
  #Sys.sleep(.2)
}


#########################################
## Now adding SGA optimization steps 
## for better visualizations
#########################################

######### full loglikelihood #########
B <- 5e2
mu.ax <- seq(-5, 15, length = B)
log.like <- length(B)
for(i in 1:length(mu.ax))
{
  log.like[i]  <- logf(dat, mu.ax[i])
}
plot(mu.ax, log.like, type = 'l', lwd = 2.5)

sga.like <- matrix(0, nrow = B, ncol = 1e2)

######### SGA without batching #########
for(j in 1:1e2)
{
  chosen <- sample(1:n, 1)
  for(i in 1:length(mu.ax))
  {
    sga.like[i,j]  <- logf(dat[chosen], mu.ax[i])
  }
  lines(mu.ax, sga.like[,j], col =  adjustcolor("red", alpha.f = .2))
  #Sys.sleep(.2)
}


max.iter <- 1e3
mu_k <- -4
t <- .2
mu.store <- numeric(length = max.iter)
for(k in 1:max.iter)
{
  old <- mu_k
  chosen <- sample(1:n, 1)
  mu_k <- old - t*f.gradient(dat[chosen], old)
  mu.store[k] <- mu_k
}

for(k in 1:100)
{
  points(x = mu.store[k], y = -45, col = adjustcolor("blue", alpha.f = .2), pch = 16)
  #Sys.sleep((max.iter - k)/max.iter)
}
#hist(mu.store, add = TRUE)
abline(v = mean(mu.store), col = "blue", lty = 2)



#########################################
## Now adding SGA optimization steps 
##  for mini-batch
#########################################

######### full loglikelihood #########
B <- 5e2
mu.ax <- seq(-5, 15, length = B)
log.like <- length(B)
for(i in 1:length(mu.ax))
{
  log.like[i]  <- logf(dat, mu.ax[i])
}
plot(mu.ax, log.like, type = 'l', lwd = 2.5)
sga.like <- matrix(0, nrow = B, ncol = 1e2)

######### SGA with mini-batching size 32 #########
for(j in 1:1e2)
{
  chosen <- sample(1:n, 10)
  for(i in 1:length(mu.ax))
  {
    sga.like[i,j]  <- logf(dat[chosen], mu.ax[i])
  }
  lines(mu.ax, sga.like[,j], col =  adjustcolor("red", alpha.f = .2))
  #Sys.sleep(.2)
}
#abline(v = c(min(dat), max(dat)), col = "blue", lty = 2)

max.iter <- 1e3
mu_k <- -4
t <- 1
mu.store <- numeric(length = max.iter)
for(k in 1:max.iter)
{
  old <- mu_k
  chosen <- sample(1:n, 32)
  mu_k <- old - t*f.gradient(dat[chosen], old)
  mu.store[k] <- mu_k
}

# viewing first 100 points
for(k in 1:100)
{
  points(x = mu.store[k], y = -45, col = adjustcolor("blue", alpha.f = .2), pch = 16)
  #Sys.sleep((max.iter - k)/max.iter)
}
abline(v = mean(mu.store), col = "blue", lty = 2)


