# set.seed(1)
# n <- 50
# p <- 5
# 
# X <- cbind(1, matrix(rnorm(n * (p-1)), ncol = p-1, nrow = n))
# beta.star <- c(.1, .2, .1, .6, -.3)
# 
# pi <- exp(X %*% beta.star)
# y <- rpois(n, pi)
# 
# data <- cbind(y, X)
# save(file = "Q_6.Rdata", data)

library(pracma)

load("Q_6.Rdata")
data <- as.data.frame(data)
x <- as.matrix(data[ ,-1])
y <- data[ ,1]

nabla.ll <- function(beta)
{
  init <- numeric(length = dim(x)[2])
  for(i in 1:dim(x)[1])
  {
    init <- init + x[i, ] * as.numeric(y[i] - exp(t(x[i, ]) %*% beta))
  }
  return(init)
}

hessian.ll <- function(beta)
{
  init <- matrix(0, nrow = dim(x)[2], ncol = dim(x)[2])
  for(i in 1:dim(x)[1])
  {
    init <- init - (x[i, ] %*% t(x[i, ])) * as.numeric(exp(t(x[i, ]) %*% beta))
  }
  return(init)
}

#-------------Newton-Raphson---------------------

# prev <- c(3, 1, 1, 2, 5)
# iter <- 0
# max <- 100
# tol <- 1e-5
# diff <- 100
# 
# while((diff > tol) && (iter < max))
# {
#   iter <- iter + 1
#   curr <- prev - (inv(hessian.ll(prev)) %*% nabla.ll(prev))
#   diff <- norm(nabla.ll(curr), type = "2")
#   prev <- curr
# }
# 
# curr

#-------------Gradient-Ascent--------------------

prev <- c(0, 2, 1, 2, 3)
iter <- 0
max <- 10000
diff <- 100
tol <- 1e-5
t <- 0.0004

while(diff > tol && iter < max)
{
  iter <- iter + 1
  curr <- prev + t * nabla.ll(prev)
  diff <- norm(nabla.ll(curr), type = "2")
  prev <- curr
}

curr

probab <- numeric(length = length(y))
for(i in 1:length(y))
{
  probab[i] <- ppois(y[i], exp(t(x[i, ]) %*% curr))
}
score <- 0
for(i in 1:length(probab))
{
  if(probab[i] > 0.5)
  {
    score <- score + 1
  }
}
plot(y, probab)