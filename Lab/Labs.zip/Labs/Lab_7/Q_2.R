# library(pracma)
# fx <- function(x)
# {
#   return(cos(x))
# }
# fDashx <- function(x)
# {
#   return(-sin(x))
# }
# fDdashx <- function(x)
# {
#   return(-cos(x))
# }

fx <- function(x)
{
  return(x^4 - 5*(x^3) + 9*x + 3)
}
fDashx <- function(x)
{
  return(4*(x^3) - 15*(x^2) + 9)
}
fDdashx <- function(x)
{
  return(12*(x^2) - 30*x)
}

# seed <- seq(-3, 2.1, length = 3)
# epsilon <- 10^(-6)
# max <- 50
# 
# theta <- matrix(0, (max+1), length(seed))
# theta[1, ] <- seed
# 
# for(i in 1:length(seed))
# {
#   diff <- 100
#   count <- 0
#   while((count < max))
#   {
#     count <- count + 1
# 
#     prev <- theta[count, i]
#     theta[count+1, i] <- prev - fDashx(prev)/fDdashx(prev)
# 
#     diff <- abs(fDashx(theta[count+1, i]))
#   }
# }
# 
# lapply(theta[max+1 ,], fx)
# x <- seq(-pi, 3*pi, length = 100)
# y <- cos(x)
# plot(x, y, type = "l")
# 
# for(i in 1:length(seed))
# {
#   x <- theta[i, -c(1)]
#   y <- cos(x)
#   points(x, y, col = i, pch = 16)
# }

seed <- 0.2
count <- 0
t <- 0.1
theta <- numeric()
theta <- c(theta, seed)
tol <- 10^(-8)
diff <- 100
while((diff > tol) && (count < 100))
{
  count <- count + 1
  curr <- theta[count] + t*fDashx(theta[count])
  theta <- c(theta, curr)
  diff <- abs(fDashx(theta[count]))
}

x <- seq(-pi, 5, length = 100)
y <- fx(x)
plot(x, y, type = "l")

x <- theta
y <- fx(x)
points(x, y, col = "red", pch = 16)