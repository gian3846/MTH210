library(pracma)

titanic <- read.csv("https://dvats.github.io/assets/titanic.csv")
x <- as.matrix(titanic[ ,-1])
y <- titanic[ ,1]

nabla.ll <- function(beta)
{
  init <- numeric(length = length(x[1, ]))
  for(i in 1:length(x[ ,1]))
  {
    init <- init + x[i, ] * as.numeric(y[i] - (1/(1 + exp(t(-x[i, ]) %*% (beta)))))
  }
  return(init)
}

prev <- c(1.5, 0, 0, 0, 0, -2.5)
tol <- 10^(-5)
iter <- 0
max <- 5000
diff <- 100
t <- 0.00005

while((diff > tol) & (iter < max))
{
  iter <- iter + 1
  curr <- prev + (t * nabla.ll(prev))
  diff <- sqrt(sum(nabla.ll(curr)^2))
  prev <- curr
}

curr

prob <- function(x)
{
  ans <- exp(t(x) %*% curr)/(1 + exp(t(x) %*% curr))
  return(ans)
}

jack <- c(1, 1, 20, 0, 0, 7.5)
prob(jack)

ross <- c(1, 0, 19, 1, 1, 512)
prob(ross)

yCal <- numeric(length = length(x[ ,1]))
for(i in 1:length(x[ ,1]))
{
  yCal[i] <- prob(x[i, ])
}

score <- 0
for(i in 1:length(x[ ,1]))
{
  if((y[i] < 0.5) && (yCal[i] < 0.5))
  {
    score <- score + 1
  }
  if((y[i] > 0.5) && (yCal[i] > 0.5))
  {
    score <- score + 1
  }
}