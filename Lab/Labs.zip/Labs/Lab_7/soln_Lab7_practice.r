titanic <- read.csv("https://dvats.github.io/assets/titanic.csv")
head(titanic)

f.gradient <- function(y, X, beta)
{
  # converting beta to compatible matrix form
  beta <- matrix(beta, ncol = 1)
  pi.vec <- 1 / (1 + exp(-X%*%beta))
  rtn <- colSums(X* as.numeric(y - pi.vec))
  return(rtn)
}

f.hessian <- function(y, X, beta)
{
  beta <- matrix(beta, ncol = 1)
  W_i <- exp(X%*%beta) / (1 + exp(X%*%beta))^2
  W <- diag(as.numeric(W_i))
  rtn <- - t(X) %*% W %*% X
}

y <- titanic$Survived
X <- as.matrix(titanic[, -1]) # everything but the first column is the X
# will need these later
p <- dim(X)[2]
n <- length(y)

tol <- 1e-10
compare <- 100
iter <- 1
# starting from the zero-vector
grad.vec <- c() # will store gradients here
beta.current <- rep(0, p)
beta.new <- beta.current
while(compare > tol)
{
  iter <- iter + 1 # tracking iterations
  gradient <- f.gradient(y, X, beta.current)
  hessian <- f.hessian(y, X, beta.current)
  beta.new <- beta.current - qr.solve(hessian) %*% gradient
  grad.vec[iter] <- norm(gradient, "2")
  beta.current <- beta.new
  compare <- grad.vec[iter]
}
iter
plot.ts(grad.vec)
beta.new



##########################3
f.gradient <- function(y, X, beta)
{
  beta <- matrix(beta, ncol = 1)
  n <- length(y)
  rtn <- colSums( t(y - exp(X %*% beta)) %*% X)
  return(rtn)
}
f.hessian <- function(y, X, beta)
{
  beta <- matrix(beta, ncol = 1)
  V_i <- exp(X %*% beta)
  V <- diag(as.numeric(V_i))
  rtn <- -t(X) %*% V %*% X
  return(rtn)
}

set.seed(1)
n <- 50
p <- 5
# generate covariates
X <- cbind(1, matrix( rnorm(n*(p-1)), ncol = p-1, nrow = n))
beta.star <- c(.1, .2, .1, .6, -.3)
pi <- exp(X %*% beta.star)
y <- rpois(n, pi) # generate response


tol <- 1e-10
compare <- 100
iter <- 1
# starting from the zero-vector
grad.vec <- c() # will store gradients here
foo <- glm(y ~ X - 1, family = poisson)
beta.current <- rep(0, p)
beta.new <- beta.current
while(compare > tol)
{
  iter <- iter + 1 # tracking iterations
  gradient <- f.gradient(y, X, beta.current)
  hessian <- f.hessian(y, X, beta.current)
  beta.new <- beta.current - qr.solve(hessian) %*% gradient
  grad.vec[iter] <- norm(gradient, "2")
  beta.current <- beta.new
  compare <- grad.vec[iter]
}
  