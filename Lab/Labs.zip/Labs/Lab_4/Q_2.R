k <- 2
N <- 1e3
a <- 2
b <- 5

# samp <- rgamma(N, a, b)
# 
# secondMoment <- mean(samp^2)

#################################################

lambda <- 1.3
samp <- rexp(N, lambda)

secondMoment <- mean((samp^2)*dgamma(samp, a, b)/dexp(samp, lambda))
varG <- var((samp^2)*dgamma(samp, a, b)/dexp(samp, lambda))

#################################################

a <- 3
b <- 3

lambda <- 0.5
samp <- rexp(N, lambda)

secondMoment <- mean((samp^2)*dgamma(samp, a, b)/dexp(samp, lambda))
varG <- var((samp^2)*dgamma(samp, a, b)/dexp(samp, lambda))

#################################################
N <- 1e3
k <- 3
a <- 4
b <- 10

samp <- rgamma(samp, shape = 7, rate = 10)

kMoment <- mean((samp^k)*dgamma(samp, shape = a, rate = b)/dgamma(samp, shape = 7, rate = 10))
varG <- var((samp^k)*dgamma(samp, a, b)/dgamma(samp, 7, 10))