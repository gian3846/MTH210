k <- 2
a <- 2
b <- 5
N <- 1e5

lambda <- 3
samp <- rexp(N, lambda)

truth <- 0.24 # from previous question

S <- (samp^k) * dgamma(samp, shape = a, rate = b) / dexp(samp, rate = lambda)

xAxis <- 1:N
yAxis <- cumsum(S)/(1:N)

plot(xAxis, yAxis, xlab = "N", ylab = "moment", ylim = c(0.20, 0.28))
abline(h = truth, col = "red")