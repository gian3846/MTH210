multinorm <- function(mu, rho, N = 5e2)
{
  sigma <- matrix(c(1, rho, rho, 1), 2, 2)
  E <- eigen(sigma)
  sigma.sqrt <- (E$vectors) %*% (diag(sqrt(E$values))) %*% t(E$vectors)
  
  samp <- matrix(0, N, 2)
  
  for(i in 1:N)
  {
    Z <- rnorm(2)
    samp[i, ] <- mu + sigma.sqrt %*% Z
  }
  
  return(samp)
}

N <- 500
samples <- multinorm(c(-5, 10), 0.8, N)

plot(samples, xlab = "X_1", ylab = "X_2")
