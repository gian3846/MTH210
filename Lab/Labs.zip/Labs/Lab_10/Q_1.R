data("mtcars")
y <- mtcars$mpg

X <- cbind(1, as.matrix(mtcars[ ,-1]))
n <- dim(X)[1]
p <- dim(X)[2]

lamVec <- 10^(seq(-8, 8, by = 0.1))
errorVec <- numeric(length = length(lamVec))

for(i in 1:length(lamVec))
{
  error <- 0
  lam <- lamVec[i]
  for(j in 1:n)
  {
    yTrain <- y[-j]
    yTest <- y[j]
    
    XTrain <- X[-j, ]
    XTest <- X[j, ]
    
    betaTrain <- solve(t(XTrain) %*% XTrain + lam*diag(1, p)) %*% t(XTrain) %*% yTrain
    
    yHat <- XTest %*% betaTrain
    
    error <- error + norm(yTest - yHat, "2")
  }
  errorVec[i] <- error/n
}

lam <- lamVec[which.min(errorVec)]

beta <- solve(t(X) %*% X + lam * diag(1, p)) %*% t(X) %*% y

yHat <- X %*% beta
loss <- norm(y - yHat, "2")