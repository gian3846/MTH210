titanic <- read.csv("https://dvats.github.io/assets/titanic.csv")

ridgeLogistic <- function(y, X, lam)
{
  nabla <- function(prev)
  {
    temp <- 0
    for(i in 1:n)
    {
      temp <- temp + X[i, ] * as.numeric(y[i] - 1/(1 + exp(-X[i, ] %*% prev))) - lam * prev
    }
    return(temp)
  }
  hessian <- function(prev)
  {
    temp <- matrix(0, p, p)
    for(i in 1:n)
    {
      temp <- temp - X[i, ] %*% t(X[i, ]) * as.numeric(exp(-X[i, ] %*% prev) / (1 + exp(-X[i, ] %*% prev))^2) - lam * diag(1, p, p)
    }
    return(temp)
  }
  
  n <- dim(X)[1]
  p <- dim(X)[2]
  
  prev <- numeric(length = p)
  iter <- 0
  max <- 1e3
  diff <- 100
  tol <- 1e-5
  while((iter < max) && (diff > tol))
  {
    iter <- iter + 1
    curr <- prev - solve(hessian(prev)) %*% nabla(prev)
    diff <- norm(curr - prev, "2")
    prev <- curr
  }
  betaHat <- curr
  return(betaHat)
}

calc <- function(X, betaHat)
{
  n <- dim(X)[1]
  yHat <- numeric(length = n)
  prob <- yHat
  
  for(i in 1:n)
  {
    prob[i] <- 1/(1 + exp(-(X[i, ] %*% betaHat))) 
    if(prob[i] >= 0.5)
    {
      yHat[i] <- 1
    }
  }
  return(yHat)
}

calcError <-function(yHat, y)
{
  loss <- 0
  for(i in 1:length(y))
  {
    if(yHat[i] != y[i])
      loss <- loss + 1
  }
  return(loss)
}

y <- titanic$Survived
X <- as.matrix(titanic[ ,-titanic$Survived])

n <- dim(X)[1]
p <- dim(X)[2]

permutation <- sample(1:n, n, replace = F)
K <- 5
indices <- split(permutation, rep(1:K, length = n, each = n/K))

lamVec <- 10^seq(-8, 8, by = 0.1)
errorVec <- numeric(length = length(lamVec))

for(l in 1:length(lamVec))
{
  lam <- lamVec[l]
  error <- 0
  for(i in 1:K)
  {
    yTrain <- y[-indices[[i]]]
    yTest <- y[indices[[i]]]
    
    XTrain <- X[-indices[[i]], ]
    XTest <- X[indices[[i]], ]
    
    betaTrain <- ridgeLogistic(yTrain, XTrain, lam)
    
    yHat <- calc(XTest, betaTrain)
    
    error <- error + calcError(yHat, yTest)
  }
  errorVec[l] <- error/n
}

lamChosen <- lamVec[which.min(errorVec)]
betaHat <- ridgeLogistic(y, X, lamChosen)
yHat <- calc(X, betaHat)
loss <- calcError(yHat, y)
