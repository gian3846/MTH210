data("mtcars")
y <- mtcars[ ,1]
X <- cbind(1, as.matrix(mtcars[ ,-1]))

n <- dim(X)[1]
p <- dim(X)[2]

permutation <- sample(1:n, n, replace = F)
K <- 10
indices <- split(permutation, rep(1:K, length = n, each = n/K))

lamVec <- 10^seq(-8, 8, by = 0.1)
errorVec <- numeric(length = length(lamVec))

for(l in 1:length(lamVec))
{
  lam <- lamVec[l]
  error <- 0
  
  for(i in 1:K)
  {
    XTrain <- X[-indices[[i]], ]
    XTest <- X[indices[[i]], ]
    
    yTrain <- y[-indices[[i]]]
    yTest <- y[indices[[i]]]
    
    betaTrain <- solve(t(XTrain) %*% XTrain + lam*diag(1, p)) %*% t(XTrain) %*% yTrain
    yHat <- XTest %*% betaTrain
    
    error <- error + sum((yHat - yTest)^2)
  }
  errorVec[l] <- error/n
}

lamChosen <- lamVec[which.min(errorVec)]
betaHat <- solve(t(X) %*% X + lamChosen * diag(1, p)) %*% t(X) %*% y
yHat <- X %*% betaHat

loss <- sum((yHat - y)^2)
loss <- loss/n