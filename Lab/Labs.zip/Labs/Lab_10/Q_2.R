data("mtcars")
y <- mtcars$mpg

X <- cbind(1, as.matrix(mtcars[ ,-1]))
n <- dim(X)[1]
p <- dim(X)[2]

permutation <- sample(1:n, n, replace = F)
K <- 4
indices <- split(permutation, rep(1:K, length = n, each = n/K))

lamVec <- 10^(seq(-8, 8, by = 0.1))
errorVec <- numeric(length = length(lamVec))

for(l in 1:length(lamVec))
{
  error <- 0
  lam <- lamVec[l]
  for(i in 1:K)
  {
    yTest <- y[indices[[i]]]
    yTrain <- y[-(indices[[i]])]
    
    XTest <- X[indices[[i]], ]
    XTrain <- X[-(indices[[i]]), ]
    
    betaTrain <- solve(t(XTrain) %*% XTrain + lam*diag(1, p)) %*% t(XTrain) %*% yTrain
    
    indError <- 0
    for(j in 1:length(yTest))
    {
      yHat <- XTest[j, ] %*% betaTrain
      indError <- indError + sum(c(yHat - y[j])^2)
    }
    error <- error + indError
  }
  errorVec[l] <- error/n
}

lam <- lamVec[which.min(errorVec)]
beta <- solve(t(X) %*% X + lam * diag(1, p)) %*% t(X) %*% y

yHat <- X %*% beta
loss <- sum((yHat - y)^2)
loss <- loss/n