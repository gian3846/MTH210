exponential <- function(lambda)
{
  u <- runif(1)
  x <- -log(1-u)/lambda
  return (x)
}

supC <- function(a, b, lambda)
{
  c <- ((b^a)/(lambda*gamma(a)))*(exp(1-a))*(((a-1)/(b-lambda))^(a-1))
}

gammaAR <- function(a, b, c, lambda)
{
  count <- 0
  accept <- 0
  
  while(accept == 0)
  {
    count = count + 1
    
    u <- runif(1)
    prop <- exponential(lambda)
    
    ratio <- ((prop^(a-1))*(b^a)*(exp(-b*prop)))/(gamma(a)*c*lambda*exp(-lambda*prop))
    
    if(u <= ratio)
    {
      accept = 1
    }
  }
  
  return(c(prop, count))
}

N <- 1e3
samp <- numeric(length = N)
count <- numeric(length = N)
lambda <- 4/3
c <- supC(4, 3, lambda)
for(i in 1:N)
{ 
  foo <- gammaAR(4, 3, c, lambda)
  samp[i] <- foo[1]
  count[i] <- foo[2]
}

hist(samp)
mean(samp)
mean(count)
c
