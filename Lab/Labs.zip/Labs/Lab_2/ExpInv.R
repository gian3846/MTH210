draw <- function()
{
  u <- runif(1)
  y <- -log(1-((1-exp(-0.05))*u))
  return (y)
}

N <- 1e3
samp <- numeric(length = N)

for(i in 1:N)
{
  samp[i] <- draw()
}

hist(samp)

mean(samp)
