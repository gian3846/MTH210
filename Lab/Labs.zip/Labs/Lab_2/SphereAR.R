set.seed(1)

sphere <- function(p)
{
  accept <- 0
  count <- 0
  
  while(accept == 0)
  {
    count <- count + 1
    
    x <- numeric(length = p)
    for(i in 1:p)
    {
      x[i] <- runif(1, -1, 1)
    }
    
    if(norm(x, type = "2") <= 1)
    {
      prop <- x
      accept <- 1
    }
  }
  return (c(prop, count))
}

N <- 1e4
p <- 3
c <- ((2^p)*(gamma(p/2 + 1)))/(pi^(p/2))

samp <- matrix(0, N, p)
try <- numeric(length = N)

for(i in 1:N)
{
  foo <- sphere(p)
  samp[i, ] <-  foo[1:p]
  try[i] <- foo[p+1]
}

scatterplot3d(samp[ ,1], samp[ ,2], samp[ ,3],angle = 30 )

mean(try)
