gx <- function(n)
{
  u <- runif(1)
  x <- 1 - (1-u)^(1/n)
  return (x)
}

beta <- function(m, n)
{
  count <- 0
  accept <- 0
  c <- gamma(m+n)/(gamma(m)*gamma(n)*n)
  while(accept == 0)
  {
    count <- count + 1
    
    u <- runif(1)
    prop <- gx(n)
    ratio <- (prop^(m-1))/n
    
    if(u < prop)
    {
      x <- prop
      accept <- 1
    }
  }
  return (c(x, count, c))
}

N <- 1e3
samp <- numeric(length = N)
count <- numeric(length = N)

for(i in 1:N)
{
  foo <- beta(2, 0.1)
  samp[i] <- foo[1]
  count[i] <- foo[2]
}

hist(samp)
mean(count)
