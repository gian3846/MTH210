drawX <- function(i, lambda)
{
  u <- runif(1)
  x <- (-log(1-u)/lambda)^(1/i)
  return (x)
}

N <- 1e3
samp <- numeric(length = N)

for(i in 1:N)
{
  for(j in 1:5)
  {
    samp[i] = samp[i] + drawX(j, )
  }
}
hist(samp)

sampSq <- samp^2
mean(sampSq)

weibull <- numeric(length = N)
for(i in 1:N)
{
  weibull[i] <- drawX(4, 100)
}
hist(weibull)