GMMoneDim <- function(x, C = 2)
{
  mu <- seq(min(x), max(x), length = C)
  sigma2 <- numeric(length = C)
  sigma2 <- sigma2 + 1
  pis <- numeric(length = C) + 0.5
  
  # Calculates the gamma_ick matrix where each element is gamma_ic of k th iteration
  gamma_ick <- function(x, mu, sigma2, pis, C)
  {
    gamma_k <- matrix(0, nrow = length(x), ncol = C)
    for(i in 1:C)
    {
      gamma_k[ ,i] <- dnorm(x, mean = mu[i], sd = sqrt(sigma2[i])) * pis[i]
    }
    gamma_k <- gamma_k/(rowSums(gamma_k))
    return(gamma_k)
  }
  
  prev <- c(mu, sigma2, pis)
  iter <- 0
  max <- 1e3
  tol <- 1e-5
  diff <- tol+1
  
  while((iter < max) & (diff > tol))
  {
    iter <- iter + 1
    
    gamma_k <- gamma_ick(x, prev[1:C], prev[(C+1):(2*C)], prev[(2*C+1):(3*C)], C)
    mu <- colSums(gamma_k*x) / colSums(gamma_k)
    for(i in 1:C)
    {
      sigma2[i] <- sum(gamma_k[ ,i] * (x - mu[i])^2) / sum(gamma_k[ ,i])
    }
    pis <- colMeans(gamma_k)
    
    curr <- c(mu, sigma2, pis)
    diff <- sum(abs(curr-prev))
    prev <- curr
  }
  #curr
  
  prob_z <- gamma_ick(x, curr[1:C], curr[(C+1):(2*C)], curr[(2*C+1):(3*C)], C)
  zis <- numeric(length = length(x))
  for(i in 1:length(x))
  {
    zis[i] <- which.max(prob_z[i, ])
  }
  return(c(zis, curr))
}

data <- faithful
# x <- data$eruptions
x <- faithful$waiting

erup2 <- GMMoneDim(x, C = 2) 
erup3 <- GMMoneDim(x, C = 3)
erup4 <- GMMoneDim(x, C = 4)
hist(x, breaks = 30, probability = T)
lines(density(x))
points(x, numeric(length = length(x)), col = erup2[1:length(x)], pch = 16)
points(x, numeric(length = length(x)), col = erup3[1:length(x)], pch = 16)
points(x, numeric(length = length(x)), col = erup4[1:length(x)], pch = 16)
#------------------------------------------------

x <- rnorm(80, 8, 1)
y <- rnorm(80, 10, 1)

z <- c(x, y)

zhat <- GMMoneDim(z, 2)
xhat <- zhat[1:length(x)]
yhat <- zhat[(length(x)+1):length(z)]

a <- cbind(x, xhat)
b <- cbind(y, yhat)

plot(density(z))

points(x, numeric(length = length(x)), col = "pink")
points(y, numeric(length = length(y)), col = "orange")
points(x, numeric(length = length(x)) + 0.01, col = xhat)
points(y, numeric(length = length(y)) + 0.02, col = yhat)

#------------------------------------------------

logLike <- function(x, z, mu, sigma2, pis)
{
  sum <- 0
  for(i in 1:length(x))
  {
    sum <- sum + pis[z[i]]*dnorm(x[i], mu[z[i]], sqrt(sigma2[z[i]]))
  }
  likelihood <- log(sum)
  return(likelihood)
}

bic <- function(likelihood, C, len)
{
  k <- 3*C - 1
  ans <- likelihood - k*log(len)
  return(ans)
}

n <- length(x)

#2
C <- 2

est <- GMMoneDim(x, C)
likelihood <- logLike(x, est[1:n], est[(n+1):(n+C)], est[(C+1+n):(2*C+n)], est[(2*C+1+n):(3*C+n)])
bic(likelihood, C, n)

#3
C <- 3

est <- GMMoneDim(x, C)
likelihood <- logLike(x, est[1:n], est[(n+1):(n+C)], est[(C+1+n):(2*C+n)], est[(2*C+1+n):(3*C+n)])
bic(likelihood, C, n)

#4
C <- 4

est <- GMMoneDim(x, C)
likelihood <- logLike(x, est[1:n], est[(n+1):(n+C)], est[(C+1+n):(2*C+n)], est[(2*C+1+n):(3*C+n)])
bic(likelihood, C, n)

#------------------------------------------------

x <- rnorm(80, 6, 1)
y <- rnorm(80, 10, 1)
a <- rnorm(80, 15, 2)

z <- c(x, y, a)

zhat <- GMMoneDim(z, 3)
xhat <- zhat[1:length(x)]
yhat <- zhat[(length(x)+1):length(c(x,y))]
ahat <- zhat[(length(c(x,y))+1):length(z)]

j <- cbind(x, xhat)
l <- cbind(y, yhat)
m <- cbind(a, ahat)

plot(density(z))

points(x, numeric(length = length(x)), col = "pink")
points(y, numeric(length = length(y)), col = "orange")
points(a, numeric(length = length(a)), col = "blue")
points(x, numeric(length = length(x)) + 0.01, col = xhat)
points(y, numeric(length = length(y)) + 0.02, col = yhat)
points(a, numeric(length = length(a)) + 0.03, col = ahat)