GMMonedim <- function(x, C)
{
  hist(x, breaks = 30, main = "Eruptions")
  #### Starting values of the estimates
  mu <- numeric(length = C)
  sig2 <- numeric(length = C)
  sig2 <- rep(1, C)
  pis <- numeric(length = C)
  pis <- rep(1/C, C)
  mu[1] <- min(x)
  for(i in 2:C)
  {
    mu[i] <- mu[i-1] + (max(x) - min(x))/C
  }
  
  ##### Setting the inital values of variables needed
  iter <- 0
  current <- c(pis, mu, sig2)
  diff <- 100
  tol <- 1e-5
  
  #### function to calculate the gamma_ick i.e. probability of a data point to be in class c
  gamma_ick <- function(x, mu, sig2, pis, C)
  {
    gamma_prob <- matrix(0, nrow = length(x), ncol = C)
    for(j in 1:C){
      gamma_prob[ ,j] <- dnorm(x, mean = mu[j], sd = sqrt(sig2[j]))*pis[j]  
    }
    gamma_prob <- gamma_prob/(rowSums(gamma_prob))
    return(gamma_prob)
  }
  
  ###### Starting the EM Algo now....
  
  current <- c(pis, mu, sig2)
  store <- current
  
  while(diff > tol)
  {
    update <- current
    iter <- iter + 1
    prob_z <- gamma_ick(x, mu, sig2, pis, C)
    pis <- colMeans(prob_z)
    mu <- colSums(prob_z*x)/colSums(prob_z)
    for(i in 1:C)
    {
      sig2[i] <- sum(prob_z[,i]*(x - mu[i])^2)/sum(prob_z[,i])
    }
    current <- c(pis, mu, sig2)
    diff <- norm(update - current, "2")
    store <- rbind(store, current)
  
  }
  current
  head(round(prob_z, 10))
  Zs <- numeric(length = length(x))
  color <- apply(prob_z, 1, which.max)
  for(i in 1:length(x))
  {
    Zs[i] <- color[i]
  }
  rtn <- list(Zs, mu, sig2, pis)
  points(x, rep(0, length(x)), pch = 16, col = color)
}
GMMonedim(faithful$eruptions, C= 2)
GMMonedim(faithful$eruptions, C = 3)


##### 6
GMMforD <- function(x, C = 2)
{
  p <- dim(x)[2]
  n <- dim(x)[1]
  
  sig2 
  sig2 <- matrix(0, nrow = p, ncol = C)

  
  
}