gamma_one_dim <- function(X, C = 2)
{
  n <- length(X)
  
  alpha <- c(1, 10)
  pis <- numeric(length = C) + 1/C
  
  gamma_ick <- function(X, C, alpha, pis)
  {
    gamma_k <- matrix(0, n, C)
    for(i in 1:C)
    {
      gamma_k[ ,i] <- dgamma(X, alpha[i], 1) * pis[i]
    }
    gamma_k <- gamma_k/rowSums(gamma_k)
    return(gamma_k)
  }
  
  max.alpha <- function(X, C, alpha, pis, gamma_k)
  {
    ans <- numeric(length = C)
    
    for(i in 1:C)
    {
      iter <- 0
      max <- 1000
      diff <- 100
      tol <- 1e-3
      prev <- alpha[i]
      while((iter < max) && (diff > tol))
      {
        iter <- iter + 1
        curr <- prev - ((-psi(0, prev)*sum(gamma_k[ ,i])) + sum(log(X) * gamma_k[ ,i]))/(-psi(1, prev) * sum(gamma_k[ ,i]))
        diff <- abs((-psi(0, prev)*sum(gamma_k[ ,i])) + sum(log(X) * gamma_k[ ,i]))
        prev <- curr
      }
      ans[i] <- curr
    }
    return(ans)
  }
  
  iter <- 0
  max <- 1e3
  diff <- 100
  tol <- 1e-5
  
  while((iter < max) && (diff > tol))
  {
    iter <- iter + 1
    prev <- c(alpha, pis)
    gamma_k <- gamma_ick(X, C, alpha, pis)
    
    alpha <- max.alpha(X, C, alpha, pis, gamma_k)
    pis <- colMeans(gamma_k)
    
    curr <- c(alpha, pis)
    
    diff <- norm(curr - prev, "2")
  }
  
  temp <- gamma_ick(X, C, alpha, pis)
  zis <- numeric(length = n)
  for(i in 1:n)
  {
    zis[i] <- which.max(temp[i, ])
  }
  
  ans <- list("zis" = zis, "alpha" = alpha, "pis" = pis)
  return(ans)
}
X <- faithful
X <- faithful$eruptions
X <- as.numeric(X)

ans2 <- gamma_one_dim(X, 2)

hist(X, breaks = 30)
y <- numeric(length = length(X))
points(X, y, col = ans2$zis)
