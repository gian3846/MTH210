library(mvtnorm)
library(ellipse)

gmm_multi_dim <- function(X, C = 2)
{
  n <- dim(X)[1]
  p <- dim(X)[2]
  
  mu <- list()
  sig <- list()
  pis <- rep(1/C, C)
  
  for(i in 1:C)
  {
    mu[[i]] <- colMeans(X[,]) + rnorm(p)
    sig[[i]] <- var(X)
  }
  
  gamma_ick <- function(X, C, mu, sig, pis)
  {
    gamma_k <- matrix(0, n, C)
    for(i in 1:C)
    {
      gamma_k[ ,i] <- dmvnorm(X, mu[[i]], sig[[i]]) * pis[[i]]
    }
    gamma_k <- gamma_k/rowSums(gamma_k)
    return(gamma_k)
  }
  
  logLike <- function(X, mu, sig, pis)
  {
    foo <- 0 
    for(c in 1:C) 
    {
      foo <- foo + pis[[c]]*dmvnorm(X, mean = mu[[c]], sigma = sig[[c]]) 
    }
    return(sum(log(foo)))
  }
  
  iter <- 0
  max <- 1e3
  tol <- 1e-5
  diff <- tol + 1
  while(iter < max & diff > tol)
  {
    iter <- iter + 1
    prev <- c(unlist(mu), unlist(sig), unlist(pis))
    gamma_k <- gamma_ick(X, C, mu, sig, pis)
    
    for(i in 1:C)
    {
      mu[[i]] <- colSums(gamma_k[ ,i] * X)/sum(gamma_k[ ,i])
    }
    for(i in 1:C)
    {
      temp <- 0
      for(j in 1:n)
      {
        temp <- temp + gamma_k[j, i] * (as.numeric(X[j, ] - mu[[i]]) %*% t(as.numeric(X[j, ] - mu[[i]])))
      }
      sig[[i]] <- temp/sum(gamma_k[ ,i])
    }
    pis <- colMeans(gamma_k)
    curr <- c(unlist(mu), unlist(sig), unlist(pis))
    diff <- norm(curr - prev, "2")
  }
  fin <- gamma_ick(X, C, mu, sig, pis)
  zis <- numeric(n)
  for(i in 1:n)
  {
    zis[i] <- which.max(fin[i, ])
  }
  loglike <- logLike(X, mu, sig, pis)
  ans <- list("zis" = zis, "mu" = mu, "sig" = sig, "pis" = pis, "loglike" = loglike)
  return(ans)
}



X <- faithful

C <- 2
ans2.1 <- gmm_multi_dim(X, C)
ans2.2 <- gmm_multi_dim(X, C)
ans2.3 <- gmm_multi_dim(X, C)
ans2.4 <- gmm_multi_dim(X, C)
par(mfrow = c(2, 2))
for(i in 1:4)
{
  model <- get(paste("ans2.", i, sep = ""))
  plot(X$eruptions, X$waiting, col = model$zis, pch = 16, xlab = "eruptions", ylab = "waiting", main = paste("Loglike", round(model$loglike, 3)))
  for(j in 1:C)
  {
    ell <- ellipse(model$sig[[j]], centre = model$mu[[j]])
    lines(ell, col = j, lwd = 2)
  }
}

C <- 3
ans3.1 <- gmm_multi_dim(X, C)
ans3.2 <- gmm_multi_dim(X, C)
ans3.3 <- gmm_multi_dim(X, C)
ans3.4 <- gmm_multi_dim(X, C)
par(mfrow = c(2, 2))
for(i in 1:4)
{
  model <- get(paste("ans3.", i, sep = ""))
  
  plot(X$eruptions, X$waiting, col = model$zis, pch = 16, xlab = "eruptions", ylab = "waiting", main = paste("Loglike", round(model$loglike, 3)))
  for(j in 1:C)
  {
    ell <- ellipse(model$sig[[j]], centre = model$mu[[j]])
    lines(ell, col = j, lwd = 2)
  }
}

kPar <- function(C, p)
{
  (C-1) + C*p + C * p*(p-1)/2
}
BIC.2 <- 2*ans2.1$loglike - log(dim(X)[1])*kPar(2, dim(X)[2])
BIC.3 <- 2*ans3.1$loglike - log(dim(X)[1])*kPar(3, dim(X)[2])